var express = require('express');
var app = express();



//both exp-demo3a.js and exp-demo3b.js are in same directory


app.listen(3000);


